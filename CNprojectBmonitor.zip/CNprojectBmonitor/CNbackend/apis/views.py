import time
from django.shortcuts import render
from django.http import HttpResponse, JsonResponse

# Create your views here.
import netifaces
import psutil
from pysnmp.hlapi import *

def network_details(request):
    print("hit")
    # Get network interface information
    interfaces = netifaces.interfaces()
    
    # Find first interface with IPv4 address
    # ip_address = None
    # for iface in interfaces:
    #     print(iface)
    #     addrs = netifaces.ifaddresses(iface)
    #     if netifaces.AF_INET in addrs:
    #         ip_address = addrs[netifaces.AF_INET][0]['addr']
    #         break
    
    # Find wireless interface and its IP address
    # wireless_interface = None
    # wireless_ip_address = None
    # for interface in netifaces.interfaces():
    #     if netifaces.AF_INET in netifaces.ifaddresses(interface):
    #         if netifaces.AF_LINK in netifaces.ifaddresses(interface):
    #             print(interface.startswith('wlo'))
    #             if interface.startswith('wlo'):
    #                 print('3')
    #                 wireless_interface = interface
    #                 wireless_ip_address = netifaces.ifaddresses(wireless_interface)[netifaces.AF_INET][0]['addr']
    #                 break

    # Find wireless interface and its IP address, subnet mask, and gateway
    wireless_interface = None
    wireless_ip_address = None
    subnet_mask = None
    gateway = None
    for interface in netifaces.interfaces():
        if netifaces.AF_INET in netifaces.ifaddresses(interface):
            if netifaces.AF_LINK in netifaces.ifaddresses(interface):
                if interface.startswith('wlo'):
                    wireless_interface = interface
                    wireless_ip_address = netifaces.ifaddresses(wireless_interface)[netifaces.AF_INET][0]['addr']
                    subnet_mask = netifaces.ifaddresses(wireless_interface)[netifaces.AF_INET][0]['netmask']
                    gateway = netifaces.gateways()[netifaces.AF_INET][0][0]
                    break

    # Get system utilization statistics
    cpu_percent = psutil.cpu_percent()
    mem_percent = psutil.virtual_memory().percent
    disk_percent = psutil.disk_usage('/').percent
    
    # Get real-time network usage graphs and charts
    packets_sent = psutil.net_io_counters().packets_sent
    packets_recv = psutil.net_io_counters().packets_recv
    bytes_sent = psutil.net_io_counters().bytes_sent
    bytes_recv = psutil.net_io_counters().bytes_recv

    # Get current network download and upload speed
    # start_time = time.time()
    # start_bytes_sent = psutil.net_io_counters().bytes_sent
    # start_bytes_recv = psutil.net_io_counters().bytes_recv
    # time.sleep(1)
    # end_time = time.time()
    # end_bytes_sent = psutil.net_io_counters().bytes_sent
    # end_bytes_recv = psutil.net_io_counters().bytes_recv
    # download_speed = (end_bytes_recv - start_bytes_recv) / (end_time - start_time)
    # upload_speed = (end_bytes_sent - start_bytes_sent) / (end_time - start_time)


    # Get current network download and upload speed
    import speedtest

    speed_test = speedtest.Speedtest()

    def bytes_to_mb(bytes):
        KB = 1024 # One Kilobyte is 1024 bytes
        MB = KB * 1024 # One MB is 1024 KB
        return int(bytes/MB)

    download_speed = bytes_to_mb(speed_test.download())
    # print("Your Download speed is", download_speed, "MB")
    upload_speed = bytes_to_mb(speed_test.upload())
    # print("Your Upload speed is", upload_speed, "MB")

    
    # Get network latency or ping time
    # ping_time = 0
    # for conn in psutil.net_connections():
    #     if conn.status == 'ESTABLISHED':
    #         rtt = getattr(conn, 'rtt', float('inf'))
    #         ping_time = max(ping_time, rtt)
    
    # Get subnet mask and gateway information
    # netmask = None
    # gateway = None
    # if wireless_ip_address:
    #     addrs = netifaces.ifaddresses(iface)
    #     if netifaces.AF_INET in addrs:
    #         netmask = addrs[netifaces.AF_INET][0]['netmask']
    #     gws = netifaces.gateways()
    #     if 'default' in gws and netifaces.AF_INET in gws['default']:
    #         gateway = gws['default'][netifaces.AF_INET][0]
    
    # Get DNS server information using SNMP
    dns_servers = []
    error_indication, error_status, error_index, var_binds = next(
        getCmd(SnmpEngine(), CommunityData('public'), UdpTransportTarget((wireless_ip_address, 161)),
               ContextData(), ObjectType(ObjectIdentity('1.3.6.1.4.1.8072.2.3.1.2.1.2')))
    )
    if not error_indication and not error_status:
        dns_servers = [x.prettyPrint().split('"')[1] for x in var_binds]


    # Create response dictionary
    response = {
        'cpu_percent': cpu_percent,
        'mem_percent': mem_percent,
        'disk_percent': disk_percent,
        'packets_sent': packets_sent,
        'packets_recv': packets_recv,
        'bytes_sent': bytes_sent,
        'bytes_recv': bytes_recv,
        'ip_address': wireless_ip_address,
        'netmask': subnet_mask,
        'gateway': gateway,
        'downloadspeed_MB': int(download_speed),
        'uploadspeed_MB': int(upload_speed)
    }
    
    # Return response as JSON
    return JsonResponse(response)
