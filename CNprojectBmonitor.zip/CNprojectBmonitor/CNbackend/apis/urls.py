from django.urls import path
from . import views

#URL configuration
urlpatterns = [
    path('bandwidth/', views.network_details),
]