import { NetworkdetailsService } from './../services/networkdetails.service';
import { Component, QueryList, ViewChild, ViewChildren } from '@angular/core';

import { NgChartsModule } from 'ng2-charts';
import { BaseChartDirective } from 'ng2-charts';

// import * as pluginDataLabels from 'chartjs-plugin-datalabels';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'CNfrontend';
  
  @ViewChildren(BaseChartDirective) charts: QueryList<BaseChartDirective>;

  data;
  cpuPercent;
  memPercent;
  diskPercent;
  downloadSpeed;
  uploadSpeed;
  packetsSent;
  packetsRecv;
  bytesSent;
  bytesRecv;
  ipAddress;
  subnetMask;
  gateway;
  maxSpeed=100;

  ///////////////// download chart
  public SystemName: string = "Speed";
  firstCopy = false;

  // data for download
  public lineChartData: Array<number> = [];
    // data for upload
  public lineChartData1: Array<number> = [];
 
  public labelMFL: Array<any> = [
      { data: this.lineChartData,
        label: this.SystemName
      }
  ];
  // labels
  public lineChartLabels: Array<any> = [];
  
  constructor(private networkService: NetworkdetailsService ) { 
    this.updateChartData();
  }

  ngOnInit(): void {
    setInterval(() => {
      this.updateChartData();
    }, 5000);
  }

  public lineChartOptions: any = {
    responsive: true,
    scales : {
      yAxes: [{
        ticks: {
          max : 60,
          min : 0,
        }
      }],
      xAxes: [{
  
 
        }],
    },
      plugins: {
      datalabels: {
        display: true,
        align: 'top',
        anchor: 'end',
        //color: "#2756B3",
        color: "#222",

        font: {
          family: 'FontAwesome',
          size: 14
        },
      
      },
      deferred: false

    },

  };

   _lineChartColors:Array<any> = [{
       backgroundColor: 'red',
        borderColor: 'red',
        pointBackgroundColor: 'red',
        pointBorderColor: 'red',
        pointHoverBackgroundColor: 'red',
        pointHoverBorderColor: 'red' 
      }];



  public ChartType = 'line';

  public chartClicked(e: any): void {
    console.log(e);
  }
  public chartHovered(e: any): void {
    console.log(e);
  }
  /////////////// upload chart
  public labelMFL1: Array<any> = [
    { data: this.lineChartData1,
      label: this.SystemName
    }
];

  updateChartData() {
    this.networkService.updateChartData().subscribe( (res:any) =>{
      this.cpuPercent=res.cpu_percent;
      this.memPercent=res.mem_percent;
      this.diskPercent=res.disk_percent;
      this.downloadSpeed=res.downloadspeed_MB;
      this.uploadSpeed=res.uploadspeed_MB;
      this.packetsSent=res.packets_sent;
      this.packetsRecv=res.packets_recv;
      this.bytesSent=res.bytes_sent;
      this.bytesRecv=res.bytes_recv;
      this.ipAddress=res.ip_address;
      this.subnetMask=res.netmask;
      this.gateway=res.gateway;

      this.lineChartLabels.push("");
      this.lineChartData.push(res.downloadspeed_MB)
      this.lineChartData1.push(res.uploadspeed_MB)
      // this.lineChartLabels.push(data)
      // if (this.chart) {
      //   this.chart.update();
      // }
      this.charts.forEach((child) => {
        child.chart.update()
    });
    },error => {
      this.cpuPercent=0;
      this.memPercent=0;
      this.diskPercent=0;
      this.downloadSpeed=0;
      this.uploadSpeed=0;
      this.packetsSent=0;
      this.packetsRecv=0;
      this.bytesSent=0;
      this.bytesRecv=0;
      this.ipAddress="connection lost";
      this.subnetMask="connection lost";
      this.gateway="connection lost";
    })
  }
}
