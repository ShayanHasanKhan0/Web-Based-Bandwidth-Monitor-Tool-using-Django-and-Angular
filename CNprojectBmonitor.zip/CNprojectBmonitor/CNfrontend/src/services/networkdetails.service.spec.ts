import { TestBed } from '@angular/core/testing';

import { NetworkdetailsService } from './networkdetails.service';

describe('NetworkdetailsService', () => {
  let service: NetworkdetailsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(NetworkdetailsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
