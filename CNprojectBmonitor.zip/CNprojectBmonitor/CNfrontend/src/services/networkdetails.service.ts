import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class NetworkdetailsService {

  constructor(private http: HttpClient) { }

  updateChartData() {
    return this.http.get('http://localhost:8000/api/bandwidth');
  }
}
